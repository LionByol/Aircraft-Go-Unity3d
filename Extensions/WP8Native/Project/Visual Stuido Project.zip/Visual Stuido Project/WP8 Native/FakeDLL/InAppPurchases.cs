﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WP8Native
{
    public class InAppPurchases
    {

        public delegate void Del(string data);
        
        public static void BuyItem(string itemID, Del callback)
        {

        }

        public static void productsInit(Del callback)
        {

        }

        public static void ShowAllPurchases()
        {

        }

        public static void LogLine(string log)
        {
        }
        
    }
}
