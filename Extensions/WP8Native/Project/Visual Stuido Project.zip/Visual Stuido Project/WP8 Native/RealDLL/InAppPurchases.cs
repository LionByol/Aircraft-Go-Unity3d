﻿using System;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Windows.ApplicationModel.Store;
using System.Linq;
using System.Collections.Generic;

namespace WP8Native
{
    public class InAppPurchases
    {
        public delegate void Del(string data);
        
        public static async void productsInit(Del callback)
        {
            StringBuilder sb = new StringBuilder();
            bool first = true;
            var listing = await CurrentApp.LoadListingInformationAsync();

            foreach (var product in listing.ProductListings)
            {
                if (!first)
                {
                    sb.Append("|");
                }
                first = false;

                sb.Append(product.Value.ImageUri);
                sb.Append("|");

                sb.Append(product.Value.Name);
                sb.Append("|");

                sb.Append(product.Key);
                sb.Append("|");

                sb.Append(product.Value.FormattedPrice);
                sb.Append("|");

                sb.Append(product.Value.ProductType);
                sb.Append("|");

                if (product.Value.Description == string.Empty)
                {
                    sb.Append(" ");
                }
                else
                {
                    sb.Append(product.Value.Description);
                }
                                
                sb.Append("|");

                if (product.Value.ProductType == ProductType.Durable)
                {
                    sb.Append(CurrentApp.LicenseInformation.ProductLicenses[product.Key].IsActive ? "True" : "False");
                }
                else
                {
                    sb.Append("False");
                }
            }

            callback(sb.ToString());
        }

        public static void LogLine(string log)
        {
            System.Diagnostics.Debug.WriteLine(log);
        }
       
        public async static void BuyItem(string InAppProductKey, Del callback)
        {
        
             try
             {
                ListingInformation products = await CurrentApp.LoadListingInformationByProductIdsAsync(new [] { InAppProductKey });
            
                ProductListing productListing = null;
                if (!products.ProductListings.TryGetValue(InAppProductKey, out productListing))
                {
                    callback("2|Could not find product information|" + InAppProductKey);
                    return;
                }

                Deployment.Current.Dispatcher.BeginInvoke( async () =>
                {
                     try
                     {
                         string receipt = await CurrentApp.RequestProductPurchaseAsync(productListing.ProductId, true);
                     
                         ProductLicense productLicense = null;
                         if (CurrentApp.LicenseInformation.ProductLicenses.TryGetValue(InAppProductKey, out productLicense))
                         {
                             if (productListing.ProductType == ProductType.Consumable)
                             {
                                 if (productLicense.IsActive)
                                 {
                                     CurrentApp.ReportProductFulfillment(InAppProductKey);

                                     callback("0|" + receipt+ "|" + InAppProductKey);
                                     return;
                                 }
                             }
                             else if (productListing.ProductType == ProductType.Durable)
                             {
                                 if (productLicense.IsActive)
                                 {
                                     callback("3|PURCHASED|" + InAppProductKey);
                                     return;
                                 }
                                 else
                                 {
                                     CurrentApp.ReportProductFulfillment(InAppProductKey);

                                     callback("0|" + receipt + "|" + InAppProductKey);
                                     return;
                                 }
                             } 

                             
                         }
                     }
                     catch (Exception e)
                     {
                         callback("1|CANCELED|" + InAppProductKey);
                     }
                });
             }
                catch (Exception e)
                {
                    callback("2|" + e.ToString() + "|" + InAppProductKey);
                }
     
            }

        public async static void ShowAllPurchases()
        {
            StringBuilder sb = new StringBuilder();
            var listing = await CurrentApp.LoadListingInformationAsync();
            foreach (var product in listing.ProductListings)
            {
                
                sb.Append(product.Key);
                sb.Append(", ");

                sb.Append(product.Value.Name);
                sb.Append(", ");

                sb.Append(product.Value.FormattedPrice);
                sb.Append(", ");

                sb.Append(product.Value.ProductType);
                sb.Append(", ");

                sb.Append(product.Value.Description);
                sb.Append(", ");

        
            }
            
            Deployment.Current.Dispatcher.BeginInvoke(() => MessageBox.Show(sb.ToString(), "List all products", MessageBoxButton.OK));
        }
    }
}
