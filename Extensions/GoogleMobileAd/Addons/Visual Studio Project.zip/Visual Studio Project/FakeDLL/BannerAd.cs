﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoogleAdsWP8
{
    public class BannerAd
    {
        public BannerAd(int format, int id, int position)
        {
                       
        }

        public void HideAd()
        {
        }
	
	    public void ShowAd() {
           
		
	    }
	    
	    public void Refresh() {
            
	    }
	
	    public void Destroy() {
		   
	    }
                
        public void SetPosition(int anchor)
        {
            
        }


        ///////////////////////
        // events
        ///////////////////////

    }
}
