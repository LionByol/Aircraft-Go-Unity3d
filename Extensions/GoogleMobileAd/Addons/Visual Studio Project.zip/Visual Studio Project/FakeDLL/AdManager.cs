﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoogleAdsWP8
{
    public class AdManager
    {

        public Action<string> InterstisialOnLoad; //ReceivedAd
        public Action<string> InterstisialFailedToLoad; //FailedToReceiveAd
        public Action<string> InterstisialOnAdOpened; //ShowingOverlay
        public Action<string> InterstisialOnAdClosed; //DismissingOverlay
        public Action<string> InterstisialAdLeftApplication; //LeavingApplication

        public Action<string> BannerOnLoad; //ReceivedAd
        public Action<string> BannerFailedToLoad; //FailedToReceiveAd
        public Action<string> BannerOnAdOpened; //ShowingOverlay
        public Action<string> BannerOnAdClosed; //DismissingOverlay
        public Action<string> BannerAdLeftApplication; //LeavingApplication

        private static AdManager _instance;

        public void Init(String ad_unit_id)
        {
            
        }

        public static AdManager instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AdManager();
                }

                return _instance;
            }
        }

        public void Refresh()
        {
            
        }

        public void EnableForceTesting()
        {
           
        }

        public void ChangeBannersUnitID(String ad_unit_id)
        {
           
        }

        public void ChangeInterstisialsUnitID(String ad_unit_id)
        {
            
        }

        public void CreateBannerAd(int format, int id, int position)
        {
                       
        }

        public void DestroyBanner(int bannerId)
        {

        }

        public void AddKeyword(String keyword)
        {
           
        }

        public void SetGender(int gender)
        {
           
        }

        public void SetBirthday(int year, int month, int day)
        {
            
        }


        private void InitInterstitialAd(String id)
        {
         
        }


        public void StartInterstitialAd()
        {

        }
        
        public void LoadInterstitialAd()
        {
            
        }

        public void ShowInterstitialAd()
        {
            
        }

        public void ShowBanner(int bannerId)
        {
        }

        public void HideBanner(int bannerId)
        {
        }

        public void RefreshBanner(int bannerId)
        {
        }

        public void SetPositionBanner(int bannerId, int position)
        {

        }

        public void SetOrientation(int orientation)
        {

        }

    }
}

