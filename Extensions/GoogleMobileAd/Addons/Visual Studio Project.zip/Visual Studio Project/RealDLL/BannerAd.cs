﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GoogleAds;
using System.Windows.Controls;
using System.Windows;

namespace GoogleAdsWP8
{
    public class BannerAd
    {
        private int _id;
        DrawingSurfaceBackgroundGrid layout;
	    private AdView banner = null;
        private bool isFirstLoad = true;

        public BannerAd(int format, int id, int position)
        {

            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                _id = id;

                banner = new AdView();

                banner.AdUnitID = AdManager.instance.Ad_unit_id;
                banner.Format = intSizeToAdSize(format);
                
                layout = AdManager.instance.Layout;
                layout.Children.Add(banner);
                
                banner.LoadAd(AdManager.instance.adRequest);

                banner.DismissingOverlay += OnDismissingOverlay;
                banner.FailedToReceiveAd += OnFailedToReceiveAd;
                banner.LeavingApplication += OnLeavingApplication;
                banner.ReceivedAd += OnReceivedAd;
                banner.ShowingOverlay += OnShowingOverlay;

            });
            
            SetPosition(position);
        }
        	
	    public void HideAd() {
            if (banner != null)
            {   
                Deployment.Current.Dispatcher.BeginInvoke(() =>
                {
                    banner.Visibility = Visibility.Collapsed;
                });
		    }
		    
            
	    }
	
	    public void ShowAd() {
            if (banner != null)
            {
                Deployment.Current.Dispatcher.BeginInvoke(() =>
                {
                    banner.Visibility = Visibility.Visible;
                });
            }
		
	    }
	    
	    public void Refresh() {

            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
               banner.LoadAd(AdManager.instance.adRequest);
            });
        
        }
	
	    public void Destroy() {
		    
            banner.DismissingOverlay -= OnDismissingOverlay;
            banner.FailedToReceiveAd -= OnFailedToReceiveAd;
            banner.LeavingApplication -= OnLeavingApplication;
            banner.ReceivedAd -= OnReceivedAd;
            banner.ShowingOverlay -= OnShowingOverlay;

            //System.Diagnostics.Debug.WriteLine("DESTROY");

            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                layout.Children.Remove(banner);
                banner = null;
                layout = null;
            });
        }
        
        private static AdFormats intSizeToAdSize(int intSize)
        {   
            switch(intSize) {
	            case 2:
                    return AdFormats.SmartBanner;
	            default:
                    return AdFormats.Banner;
	        }   
	    }

        public void SetPosition(int anchor)
        {   
            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                if (banner.Format == AdFormats.SmartBanner)
                {
                    switch (anchor)
                    {
                        case 0:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                            break;
                        case 1:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                            break;
                        case 2:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                            break;
                        case 3:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                            break;
                        case 4:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                            break;
                        case 5:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                            break;
                        case 6:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
                            break;
                        case 7:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
                            break;
                        case 8:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
                            break;
                    }
                }
                else
                {

                    switch (anchor)
                    {
                        case 0:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                            break;
                        case 1:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
                            break;
                        case 2:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                            break;
                        case 3:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                            break;
                        case 4:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
                            break;
                        case 5:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                            break;
                        case 6:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                            break;
                        case 7:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
                            break;
                        case 8:
                            banner.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
                            banner.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                            break;
                    }
                }
            });
            
        }


        ///////////////////////
        // events
        ///////////////////////

        private void OnDismissingOverlay(object sender, AdEventArgs e)
        {
            AdManager.instance.BannerOnAdClosed(_id.ToString());
            //System.Diagnostics.Debug.WriteLine("On Dismissing Overlay: " + e.ToString());
        }

        private void OnFailedToReceiveAd(object sender, AdErrorEventArgs e)
        {
            AdManager.instance.BannerFailedToLoad(_id.ToString());
            //System.Diagnostics.Debug.WriteLine("On Failed To Receive Ad: " + e.ErrorCode);
        }

        private void OnLeavingApplication(object sender, AdEventArgs e)
        {
            AdManager.instance.BannerAdLeftApplication(_id.ToString());
            //System.Diagnostics.Debug.WriteLine("On Leaving Application: " + e.ToString());
        }

        private void OnReceivedAd(object sender, AdEventArgs e)
        {
            if (isFirstLoad)
            {
                HideAd();
                isFirstLoad = false;
            }
            AdManager.instance.BannerOnLoad(_id.ToString() + "|"+ banner.ActualWidth.ToString() + "|"+ banner.ActualHeight.ToString());
            //System.Diagnostics.Debug.WriteLine("On Received Ad: " + e.ToString());
        }

        private void OnShowingOverlay(object sender, AdEventArgs e)
        {
            AdManager.instance.BannerOnAdOpened(_id.ToString());
            //System.Diagnostics.Debug.WriteLine("On Showing Overlay: " + e.ToString());
        }
    }
}
