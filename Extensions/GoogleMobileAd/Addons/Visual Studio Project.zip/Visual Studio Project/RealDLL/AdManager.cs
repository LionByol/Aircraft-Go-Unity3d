﻿using GoogleAds;
using Microsoft.Phone.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace GoogleAdsWP8
{
    public class AdManager
    {
        private static AdManager _instance;

        private string _ad_unit_id = "";

        private bool ShowOnLoad = false;

        private string _insterstisials_ad_unit_id = "";
        
        private DrawingSurfaceBackgroundGrid layout;
        private PhoneApplicationPage mainPage;

        private Dictionary<int, BannerAd> banners = new Dictionary<int, BannerAd>();

        private bool IsInited = false;
        public AdRequest adRequest;

        private InterstitialAd interstisialBanner = null;

        private List<string> _keywords;

        public Action<string> InterstisialOnLoad; //ReceivedAd
        public Action<string> InterstisialFailedToLoad; //FailedToReceiveAd
        public Action<string> InterstisialOnAdOpened; //ShowingOverlay
        public Action<string> InterstisialOnAdClosed; //DismissingOverlay
        public Action<string> InterstisialAdLeftApplication; //LeavingApplication
        
        public Action<string> BannerOnLoad; //ReceivedAd
        public Action<string> BannerFailedToLoad; //FailedToReceiveAd
        public Action<string> BannerOnAdOpened; //ShowingOverlay
        public Action<string> BannerOnAdClosed; //DismissingOverlay
        public Action<string> BannerAdLeftApplication; //LeavingApplication
        

        public string Ad_unit_id
        {
            get { return _ad_unit_id; }
        }

        public string Insterstisials_ad_unit_id
        {
            get { return _insterstisials_ad_unit_id; }
        }

        public void EnableForceTesting()
        {
            adRequest.ForceTesting = true;
        }

        public void Init(String ad_unit_id)
        {
            if (IsInited)
            {
                return;
            }

            IsInited = true;

            _keywords = new List<string>();

            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                layout = ((Application.Current.RootVisual as PhoneApplicationFrame).Content as PhoneApplicationPage).Content as DrawingSurfaceBackgroundGrid;
                mainPage = (Application.Current.RootVisual as PhoneApplicationFrame).Content as PhoneApplicationPage;
            });

            
            Refresh();
            
            _ad_unit_id = ad_unit_id;
            _insterstisials_ad_unit_id = ad_unit_id;

        }

        public void SetOrientation(int orientation)
        {
            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                mainPage.SupportedOrientations = intToOrientation(orientation);
                //System.Diagnostics.Debug.WriteLine("ORIENTATION "+intToOrientation(orientation).ToString());
                
            });
        }

        private SupportedPageOrientation intToOrientation(int orientation)
        {
            switch (orientation)
            {
                case 1:
                    return SupportedPageOrientation.Landscape;
                case 2:
                    return SupportedPageOrientation.Portrait;
               
                default:
                    return SupportedPageOrientation.PortraitOrLandscape;
            }
        }

        public void Refresh()
        {
            adRequest = new AdRequest();
            
        }

        public static AdManager instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AdManager();
                }

                return _instance;
            }
        }

        public DrawingSurfaceBackgroundGrid Layout
        {
            get { return layout; }
        }

        public void ChangeBannersUnitID(String ad_unit_id)
        {
            _ad_unit_id = ad_unit_id;
        }

        public void ChangeInterstisialsUnitID(String ad_unit_id)
        {
            _insterstisials_ad_unit_id = ad_unit_id;
        }

        public void CreateBannerAd(int format, int id, int position)
        {

            if (!IsInited)
            {
                return;
            }
            //System.Diagnostics.Debug.WriteLine("Banner with id: " + id + " created");
            BannerAd banner = new BannerAd(format, id, position);
            banners.Add(id, banner);
        }

        public void ShowBanner(int bannerId)
        {

            if (banners.ContainsKey(bannerId))
            {
                BannerAd banner = banners[bannerId];
                banner.ShowAd();
            }
            else
            {
                //System.Diagnostics.Debug.WriteLine("Banner with id: " + bannerId + " not found");
            }

        }

        public void HideBanner(int bannerId)
        {

            if (banners.ContainsKey(bannerId))
            {
                BannerAd banner = banners[bannerId];
                banner.HideAd();
            }
            else
            {
                //System.Diagnostics.Debug.WriteLine("Banner with id: " + bannerId + " not found");
            }

        }

        public void RefreshBanner(int bannerId)
        {

            if (banners.ContainsKey(bannerId))
            {
                BannerAd banner = banners[bannerId];
                Refresh();
                banner.Refresh();
            }
            else
            {
                //System.Diagnostics.Debug.WriteLine("Banner with id: " + bannerId + " not found");
            }

        }

        public void SetPositionBanner(int bannerId, int position)
        {

            if (banners.ContainsKey(bannerId))
            {
                BannerAd banner = banners[bannerId];
                banner.SetPosition(position);
            }
            else
            {
                //System.Diagnostics.Debug.WriteLine("Banner with id: " + bannerId + " not found");
            }

        }

        public void DestroyBanner(int bannerId)
        {

            if (banners.ContainsKey(bannerId))
            {
                BannerAd banner = banners[bannerId];
                banner.Destroy();
                banners.Remove(bannerId);
            }
            else
            {
                //System.Diagnostics.Debug.WriteLine("Banner with id: " + bannerId + " not found");
            }

        }

        public void AddKeyword(String keyword)
        {
            if (!IsInited)
            {
                return;
            }
            _keywords.Add(keyword);

            adRequest.Keywords = _keywords.ToArray();
        }

        public void SetGender(int gender)
        {
            if (!IsInited)
            {
                return;
            }

            adRequest.Gender = (UserGender)gender;
        }

        public void SetBirthday(int year, int month, int day)
        {
            if (!IsInited)
            {
                return;
            }

            DateTimeOffset dt = new DateTimeOffset();

            dt.AddYears(year);
            dt.AddMonths(month);
            dt.AddDays(day);

            adRequest.Birthday = dt;

            //System.Diagnostics.Debug.WriteLine("Date " + dt.Date);
        }

        public void StartInterstitialAd()
        {

            LoadInterstitialAd();
            ShowOnLoad = true;
        }
        
        public void LoadInterstitialAd()
        {
            ShowOnLoad = false;
            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                try
                {
                    interstisialBanner = new InterstitialAd(_insterstisials_ad_unit_id);
                    interstisialBanner.LoadAd(adRequest);

                    interstisialBanner.ReceivedAd += OnInterstisialReceivedAd;
                    interstisialBanner.DismissingOverlay += OnInterstisialDismissingOverlay;
                    interstisialBanner.FailedToReceiveAd += OnInterstisialFailedToReceiveAd;
                    interstisialBanner.LeavingApplication += OnInterstisialLeavingApplication;
                    interstisialBanner.ShowingOverlay += OnInterstisialShowingOverlay;
                }
                catch { }
               
            });
        }

        public void ShowInterstitialAd()
        {
            if (interstisialBanner == null)
            {
                return;
            }

            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                try
                {
                    interstisialBanner.ShowAd();
                }
                catch { }

            });
        }

        private void OnInterstisialDismissingOverlay(object sender, AdEventArgs e)
        {
            InterstisialOnAdClosed(e.ToString());
            //System.Diagnostics.Debug.WriteLine("On Dismissing Overlay: " + e.ToString());
        }

        private void OnInterstisialFailedToReceiveAd(object sender, AdErrorEventArgs e)
        {
            InterstisialFailedToLoad(e.ToString());
            //System.Diagnostics.Debug.WriteLine("On Failed To Receive Ad: " + e.ToString());
        }

        private void OnInterstisialLeavingApplication(object sender, AdEventArgs e)
        {
            InterstisialAdLeftApplication(e.ToString());
            //System.Diagnostics.Debug.WriteLine("On Leaving Application: " + e.ToString());
        }

        private void OnInterstisialReceivedAd(object sender, AdEventArgs e)
        {   
            if (ShowOnLoad) {
                ShowInterstitialAd();
            }

            InterstisialOnLoad(e.ToString());
            //System.Diagnostics.Debug.WriteLine("On Received Ad: " + e.ToString());
        }

        private void OnInterstisialShowingOverlay(object sender, AdEventArgs e)
        {
            InterstisialOnAdOpened(e.ToString());
           // System.Diagnostics.Debug.WriteLine("On Showing Overlay: " + e.ToString());
        }
    }
}
